const express = require("express");
const app = express();

app.get("", (req, res) => {
    return res.send("Hello...");
})

let books = {
    "book1": "i am book1",
    "book2": "i am book2",
    "book3": "i am book3",
    "book4": "i am book4",

}
app.get("/books", (req, res) => {
   return res.send(books) 
})
app.listen(2001, () => {
    console.log("u r running on port 2001");
})